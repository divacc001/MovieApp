
import MovieCard from "./MovieCard";

function MovieList({ movies }) {
    console.log(movies)
    return (

        <div style={{ display: 'flex', flexWrap: "wrap", justifyContent: "space-around", gap: "20" }}>

            {movies.map(movie => (
                <MovieCard key={movie.id} movies={movie} />
            ))}
        </div>


    )


}

export default MovieList;
