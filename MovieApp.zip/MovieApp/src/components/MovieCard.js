import React from 'react'
import Card from 'react-bootstrap/Card';
function MovieCard({ movies }) {
  return (


    <Card style={{ width: '18rem', marginBottom: "20px" }}>
      <Card.Img variant="top" src={movies.posterURL} />
      <Card.Body>
        <Card.Title>{movies.title}</Card.Title>
        <Card.Text>
          {movies.description}
        </Card.Text>
        <Card.Text>
          <h5 style={{ color: 'blue', fontSize: '18px' }}> rating: {isNaN(parseFloat(movies.rating)) ? 'N/A' : parseFloat(movies.rating).toFixed(1)}</h5>
        </Card.Text>
      </Card.Body>
    </Card>

  )
}

export default MovieCard