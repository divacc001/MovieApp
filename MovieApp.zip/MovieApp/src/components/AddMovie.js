import React, { useState } from 'react';
import {
  MDBBtn,
  MDBModal,
  MDBModalDialog,
  MDBModalContent,
  MDBModalHeader,
  MDBModalTitle,
  MDBModalBody,
  MDBModalFooter,
} from 'mdb-react-ui-kit';
import { MDBInput } from 'mdb-react-ui-kit';
import { MDBTextArea } from 'mdb-react-ui-kit';


export default function AddMovie({ addNewMovie }) {
  const [centredModal, setCentredModal] = useState(false);
  const [newMovie, setNewMovie] = useState(
    {
      id: Date.now().toString(36) + Math.random().toString(36).substr(2),
      title: '',
      description: '',
      posterURL: '',
      rating: 'Rate Movie'
    }


  )

  const handleChange = (e) => {

    setNewMovie({ ...newMovie, [e.target.id]: e.target.value })
  }
  const toggleOpen = () => setCentredModal(!centredModal);
  const handleUpdate = () => {

    console.log(newMovie)
    addNewMovie(newMovie)
    toggleOpen()
  }
  return (
    <>
      <MDBBtn style={{ width: "150px", marginLeft: "40x", height: "40px" }} onClick={toggleOpen}>Add Movie</MDBBtn>

      <MDBModal tabIndex='-1' open={centredModal} setOpen={setCentredModal}>
        <MDBModalDialog centered>
          <MDBModalContent>
            <MDBModalHeader>
              <MDBModalTitle>Movie Details</MDBModalTitle>
              <MDBBtn className='btn-close' color='none' onClick={toggleOpen}></MDBBtn>
            </MDBModalHeader>
            <MDBModalBody style={{ display: "flex", flexDirection: "column", gap: "20px" }}>
              <MDBInput value={newMovie.title} label='Title' id='title' type='text' onChange={handleChange} />
              <MDBTextArea value={newMovie.description} label='Description' id='description' rows={4} onChange={handleChange} />
              <MDBInput value={newMovie.posterURL} label='Poster URL' id='posterURL' type='url' onChange={handleChange} />

            </MDBModalBody>
            <MDBModalFooter>
              <MDBBtn color='secondary' onClick={toggleOpen}>
                Close
              </MDBBtn>
              <MDBBtn onClick={handleUpdate}>Save changes</MDBBtn>
            </MDBModalFooter>
          </MDBModalContent>
        </MDBModalDialog>
      </MDBModal>
    </>
  );
}