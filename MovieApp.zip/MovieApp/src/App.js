import 'bootstrap/dist/css/bootstrap.min.css';
import 'mdb-react-ui-kit/dist/css/mdb.min.css';
import "@fortawesome/fontawesome-free/css/all.min.css";
import MovieList from './components/MovieList';
import Filter from './components/Filter';
import axios from "axios";
import React, { useEffect, useState } from "react";
import AddMovie from './components/AddMovie';


function App() {

  const [movies, setMovies] = useState([]);
  const options = {
    method: 'GET',
    headers: {
      accept: 'application/json',
      Authorization: 'Bearer eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiJhM2JhNzY0MjkyMTdmNmIxZDkzNzQzMDA0ODkzMWJmMyIsInN1YiI6IjY1Y2U3MTU2NTQzN2Y1MDE3YzQxMWUzYSIsInNjb3BlcyI6WyJhcGlfcmVhZCJdLCJ2ZXJzaW9uIjoxfQ.T8Yk1CqlM4LmMPaHwHmLqABzAG6iQNKH-EhIPIxCYQM'
    }
  };



  useEffect(() => {
    axios
      .get('/3/discover/movie?include_adult=false&include_video=false&language=en-US&page=1&sort_by=popularity.desc', options)
      .then((response) => {
        const updatedMovies = response.data.results.map(movie => {
          return {
            description: movie.overview, rating: movie.vote_average, posterURL: `https://image.tmdb.org/t/p/w500${movie.poster_path}`, ...movie

          };
        });
        setMovies(updatedMovies)
      })
      .catch((error) => {
        console.error("Error fetching data: ", error);
      });
  }, []);
  const filterList = (title) => {
    if (title) {
      const filteredData = movies.filter(item =>
        item.title.toLowerCase().includes(title.toLowerCase())
      );
      console.log(filteredData)
      setMovies(filteredData);
      console.log(movies)

    } else {
      setMovies(movies);
    }
  };
  const addNewMovie = (newMovie) => {
    setMovies([...movies, newMovie])
    console.log(movies)
  }

  return (
    <div>

      <h1 style={{
        textAlign: "center",
        marginBottom: "50px",
        fontSize: "36px",
        color: "#333333",
        fontWeight: "bold",
        paddingTop: "20px"
      }}> List of Movies </h1>
      
      <div style={{ display: "flex", justifyContent: "space-around", gap: "600px" }}>
        <Filter movie={movies} filterList={filterList} />
        
        <AddMovie addNewMovie={addNewMovie} />
      </div>

      {movies.length > 0 ? (
        <MovieList movies={movies} />
      ) : (
        <h2 style={{ textAlign: 'center' }}>No movies found</h2>
      )}
    </div>
  )
}

export default App


